package com.ims.controllers;

import com.ims.bean.ItemBean;
import com.ims.servicefactory.ServiceFactory;
import com.ims.services.ItemService;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author techm
 */
public class AddItemDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	response.setContentType("text/html");
		
		
		String itemID=request.getParameter("itemid");
		String itemName=request.getParameter("itemname");
		String itemType=request.getParameter("itemtype");
		String itemPrice=request.getParameter("itemprice");
		String itemQuantity=request.getParameter("quantity");
		String vendorID=request.getParameter("vendorid");	
		String warehouseID=request.getParameter("warehouseid");	
		
		ItemBean additem=new ItemBean();
		
		additem.setItemID(itemID);
		additem.setItemName(itemName);
		additem.setItemType(itemType);
		additem.setPrice(itemPrice);
		additem.setQuantity(itemQuantity);
		additem.setVendorID(vendorID);
		additem.setWarehouseID(warehouseID);		
		
		ItemService itemService = ServiceFactory.getItemService();
            
		try{
			itemService.addItem(additem);
		}
		catch (SQLException e) {			
			e.printStackTrace();
                        RequestDispatcher rd=request.getRequestDispatcher("Sqlexception.jsp");
		        rd.forward(request, response);
		} 
                catch (ClassNotFoundException e) {			
			e.printStackTrace();
		}
		/*request.setAttribute("rs", rs);*/
		System.out.println("item added successfully");
		
	
		RequestDispatcher rd=request.getRequestDispatcher("ItemDetailsScreen.jsp");
		rd.forward(request, response);
	}

}
