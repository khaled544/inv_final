package com.ims.controllers;

import java.io.IOException;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.ims.bean.VendorBean;
import com.ims.servicefactory.ServiceFactory;

import com.ims.services.VendorService;


public class SearchByVendor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
       
		String vendorID=request.getParameter("vendorid");
		
		VendorBean searchvendor=new VendorBean();
		
		searchvendor.setVendorID(vendorID);
		
		VendorService vendorService = ServiceFactory.getVendorService();
		try{
			ResultSet rs=vendorService.searchVendor(searchvendor);
			request.setAttribute("rs", rs);
			
		}
		catch (SQLException e) {			
			e.printStackTrace();
                        RequestDispatcher rd=request.getRequestDispatcher("Sqlexception.jsp");
		        rd.forward(request, response);
		} catch (ClassNotFoundException e) {			
			e.printStackTrace();
		}
		System.out.println("searched successfully");
		RequestDispatcher rd=request.getRequestDispatcher("SearchByVendor.jsp");
		rd.include(request, response);
	}
	}
