package com.ims.daointerfaces;

import java.sql.SQLException;

import com.ims.bean.LoginBean;

public interface LoginDao {

	public abstract String validateUser(LoginBean login) throws ClassNotFoundException, SQLException;		
	
}
