/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ims.daointerfaces;

/**
 *
 * @author techm
 */

import java.sql.SQLException;

import com.ims.bean.RegistrationBean;

public interface RegistrationDao {
	public abstract boolean InsertDetails(RegistrationBean register) throws ClassNotFoundException,SQLException;
		
}