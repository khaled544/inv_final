package com.ims.daoImplementations;

import com.ims.bean.VendorBean;
import com.ims.bean.WarehouseBean;
import com.ims.daointerfaces.VendorDao;
import com.ims.utilty.DBUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class VendorDaoImplementation implements VendorDao {

	@Override
	public void addVendor(VendorBean vendor)
			throws ClassNotFoundException, SQLException {
		
		Connection con = DBUtility.getConnection();
		
		Statement st=con.createStatement();
		if(st==null){
			//System.out.println("Not Connected");
		}
		else{
			//System.out.println("Connected");
		}
		
        PreparedStatement psmt = con.prepareStatement("insert into vendordetails values(?,?,?,?)");
                 
         psmt.setString(1, vendor.getVendorID());
         psmt.setString(2, vendor.getVendorName());
         psmt.setString(3, vendor.getVendorPhoneNumber());
         psmt.setString(4, vendor.getVendorAddress());
         
         //System.out.println("Vendor Added Successfully"); 
         
         psmt.executeUpdate();
         DBUtility.closeConnection(con);
         
         
	}



    @Override
	public void modifyVendor(String VendorID,VendorBean vendor) throws ClassNotFoundException,SQLException {
            Connection con = DBUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("update VendorDetails set vendorname=?,vendorphonenumber=?,vendoraddress=? where vendorid=?");
		 psmt.setString(4, vendor.getVendorID());
                 psmt.setString(1, vendor.getVendorName());
                 psmt.setString(2, vendor.getVendorPhoneNumber());
                 psmt.setString(3, vendor.getVendorAddress());
		 
		 //
                 System.out.println("Record modified Successfully");
	psmt.executeUpdate();	 
         DBUtility.closeConnection(con); 
          /*  Connection con =null;
		String role="";
		
		con = DBUtility.getConnection();
		if(con!=null)
		{
			String sql="UPDATE VendorDetails SET vendorName=?,venndorPhonenumber=?,vendoraddress=? WHERE  vendorId=? ";
			
			
				try{
						PreparedStatement pstmt = con.prepareStatement(sql);
						
						
						pstmt.setString(4,vendor.getVendorID());
						pstmt.setString(1,vendor.getVendorName());
						pstmt.setString(2,vendor.getVendorName());
						pstmt.setString(3,vendor.getVendorAddress());
						System.out.println("dfdf");
						
						
						
						
						int rs = pstmt.executeUpdate();
						
						if(rs==1)
						{
							role="updated";
						}
                                                else{ role="failure";
                                                }
				}
						
				
					catch(SQLException e){
						e.printStackTrace();
					}
					finally
					{
					try {
						DBUtility.closeConnection(con);
						}
					catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		return role;*/
        

		
	}    


		
	



        
    @Override
	public void deleteVendor(VendorBean vendor) throws ClassNotFoundException,
			SQLException {
		
		Connection con = DBUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("delete from vendorDetails where vendorid=?	");
		 //psmt.setString(1, vendor.getVendorID()endorID());
		 psmt.setString(1, vendor.getVendorID());
		 System.out.println("Record Deleted Successfully");
		 
		 psmt.executeUpdate();
        DBUtility.closeConnection(con);	
}



    /**
     *
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */

    @Override
	public ResultSet  viewVendor() throws ClassNotFoundException,	SQLException {
		
		 Connection con = DBUtility.getConnection();
		 Statement st=con.createStatement();
		 
		 ResultSet rs=st.executeQuery("select * from vendordetails");		 
		 	 		 		 
		 /*while(rs.next()){
		 System.out.println("Vendor ID: "+rs.getString("vendorid"));
		 System.out.println("Vendor Name: "+rs.getString("vendorname"));
		 System.out.println("Address: "+rs.getString("address"));
		 System.out.println("Phone No: "+rs.getString("phonenumber"));		 		
		 System.out.println(" \n");
		 }*/
		return rs;		
		/*DBUtility.closeConnection(con); */
	}

	
    @Override
	public ResultSet searchVendor(VendorBean vendor) throws ClassNotFoundException,SQLException {
		Connection con = DBUtility.getConnection();
		PreparedStatement preparedStatement=con.prepareStatement("select * from vendordetails where vendorid=?");
		preparedStatement.setString(1, vendor.getVendorID());
		ResultSet set=preparedStatement.executeQuery();
		return set;
	}


}
