package com.ims.daoImplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ims.bean.LoginBean;
import com.ims.daointerfaces.LoginDao;
import com.ims.utilty.DBUtility;

public class LoginDaoImplementation implements LoginDao {

	public String validateUser(LoginBean login)throws ClassNotFoundException , SQLException{
	
		String role="";
		Connection con=DBUtility.getConnection();
		PreparedStatement ps=con.prepareStatement("select role from LoginDetails where username=? and password=?");
		
		ps.setString(1, login.getUserName());
		ps.setString(2, login.getPassWord());
		
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			role=rs.getString("role");
		}
		else{
			role="invalid";
		}		
		return role;
	}
}
